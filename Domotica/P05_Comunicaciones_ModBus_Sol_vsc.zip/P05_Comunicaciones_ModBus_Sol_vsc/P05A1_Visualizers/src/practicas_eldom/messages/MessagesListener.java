package practicas_eldom.messages;

public interface MessagesListener {
	void msglog(String msg);
}
