package practicas_eldom.messages;

public class VisualizerMessages {
	public final static String	DOMOBOARD 		= "Domoboard";
	public final static String	PRUEBAS 		= "Pruebas";
}
