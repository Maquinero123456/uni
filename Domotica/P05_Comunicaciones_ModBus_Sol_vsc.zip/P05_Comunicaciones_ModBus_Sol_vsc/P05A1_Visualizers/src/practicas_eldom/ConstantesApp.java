package practicas_eldom;

import CommTransport.Comm.tCommConnector;

public class ConstantesApp 
{
	//IniFiles Params
	
	public static final String 			WINDOW_TITLE = "PR�CTICAS ELECTR�NICA PARA DOM�TICA - INTERFACE JAVA "; 
	public static final String 			STATUSBAR_MSGLEFT = "Puerto seleccionado para comunicaci�n ModBus : ";
	
	public static final tCommConnector	SERIALCONNECTION = tCommConnector.CN_JSSC;  //tCommConnector.CN_RXTX; //
}